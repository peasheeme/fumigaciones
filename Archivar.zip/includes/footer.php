<!--footer-->
<footer class="azul-fuerte padding footer-color">
		<div class="container">
			<div class="row">
				<div class="col-xs-12  col-sm-12 col-md-12 col-lg-6">
				  <h3 class="footer"><strong>TECHNO & FUM</strong></h3>
					<p class="blanco"> Fumigación, diágnostico, asesoría, jardinería , servicio de control y prevención de plagas. <span class="mostrar-footer"><strong>  ¡SERVICIO A NIVEL NACIONAL!</strong> </span> <span class="oculto-footer"><strong> <br> ¡SERVICIO A NIVEL NACIONAL!</strong> </span> </p>
					<div class="oculto-copy ">
					<span class="copy">Copyright © TECHNO & FUM 2018, Todos los derechos reservados. </span> <br>
				  <span class="copy"> <a style=" color: white"  href="privacidad.php" target="_blank">Política de Privacidad </a> <a  style=" color: white" href="https://kalamedia.mx/" target="_blank">  | Sitio web Diseñado por <img src="images/iconos/kalamedia.png" width="80" alt="kalamedia"> </a></span> <br> <br>
			
					</div>
						</div>
				 <br><br>
	  
				<div class="col-xs-6 col-lg-3 margen-movil" >
				<h5 class="margen-movil " ><strong>TECHNO&FUM</strong></h5>
				<a class="footer-link" href="index.php"><span >INICIO</span></a> <br> 
				  <a class="footer-link" href="servicios.php"><span >SERVICIOS Y PRODUCTOS</span></a> <br> 
				  <a class="footer-link" href="nosotros.php"><span>NOSOTROS</span></a><br>
				  <a class="footer-link" href="contacto.php"><span>CONTACTO</span></a>
				</div>
 
				<div class="col-xs-6 col-lg-3 margen-movil2">
					<h5 class="margen-movil"><strong>CONTÁCTANOS</strong></h5>
	  
					<a class="footer-link" href="tel:0183363636"><i class="fas fa-phone dos"></i> 01 800-837-9360</a>
					<br/>
					<a class="footer-link" href="tel:8112573946"><i class="fas fa-mobile-alt dos"></i> 811 257 3946</a>
					<br/>
					<a class="footer-link" href="tel:8112573947"><i class="fas fa-mobile-alt dos"></i> 811 257 3947</a>
					<br/>
					<a class="footer-link"  href="https://api.whatsapp.com/send?phone=528128957827" target="_blank"><i class="fab fa-whatsapp dos"></i> 812 895 7827</a><!--whatsap-->
					<br/>
					<a class="footer-link" href="mailto:ventas@technofum.com.mx">	<i class="fas fa-envelope dos"></i> E-mail</a>
					<br/> 
					<a class="footer-link" href="https://www.facebook.com/monterrey.technofum" target="_blank" class="redes-sociales"> <i class="fab fa-facebook-f dos" ></i>@mty.technofum</a>
					
				</div>

				
				
			  </div><!-- .col -->
			</div><!-- .row -->
			<div class="container">
			<div class="row justify-conten">
			<div class="mostrar-copy ">
					<span class="copy">Copyright © TECHNO & FUM 2018, Todos los derechos reservados. </span> <br>
				  <span class="copy"> <a style=" color: white" href="privacidad.php" target="_blank">Política de Privacidad </a> <a  style=" color: white" href="https://kalamedia.mx/" target="_blank">  | Sitio web Diseñado por <img src="images/iconos/kalamedia.png" width="80" alt="kalamedia"> </a></span> <br> <br>
			
			</div>
			</div>
			
				
			</div>
		</div><!-- .container -->
	</footer>

<!--animaciones-->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<!--Bootstrap scripts-->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
<!--jQuery-->
<script src="js/jquery.js"></script>
<script src="js/jquery-2.1.4.js"></script>
<script src="js/jquery-1.11.0.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<!--owl-carousel-->
<script src="js/custom.js"></script>
<!--Iniciar DATA-AOS-->
<script>
	AOS.init();
</script>
