<section class="cabecera">
		
			<div class="row  justify-content-xs-center justify-content-end ">
				<div class="col-xs-12 ">
					<span class="iconos-cabecera"></span>
					<span class="iconos-cabecera">  <strong>SERVICIO A NIVEL NACIONAL</strong>	</span>
					<span class="iconos-cabecera"><a href="tel:018008379360"><i class="fas fa-phone"></i></a></span>
					<span class="iconos-cabecera"><a href="tel:018008379360"><i class="fas fa-phone"></i> <strong> 01 800 837 9360</strong> </a></span>
				</div>
		 	</div>
		
	</section>


	<!-- NavBar-->
	<section id="Barra-Navegacion" class="  " >
		<header>
			<input type="checkbox" id="btn-menu">
			<label for="btn-menu" class="hamburger hamburger--emphatic-r">
				<span class="hamburger-box">
				  <span class="hamburger-inner"></span>
				</span>
			</label>
			<a href="index.php"><img  class="brand-mostrar"src="images/iconos/logo2.png" alt="logotipo" style="margin: -40px 0 12px 50%;" ></a>
			
		   
		   <nav class="menu-responsive navbar ">
		  
				<a class="navbar-brand  brand-oculta" href="index.php" style="padding-top: 13px; margin-bottom: -28px;">
					<img src="images/iconos/logo2.png" alt="logotipo" >
				</a>
				
				<ul class="nav  justify-content-end ">
					<li class="nav-item">
						<a class="nav-link" id="op0" href="index.php">Inicio</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="op1" href="servicios.php">Servicios y Productos </a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="op2" href="nosotros.php">Nosotros</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" id="op3" href="contacto.php">Contacto</a>
					</li>
				</ul>
			</nav>
		   </div>
							
		</header>
	</section>




	<!-- /NavBar-->